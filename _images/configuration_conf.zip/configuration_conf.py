import sys

JIRA_BASE = 'http://jira.example.org/'
JIRA_USER = 'some_user'
JIRA_PASSWORD = 'some_password'


JIRA_REST = JIRA_BASE + '/rest/gitplugin/1.0/configuration'
