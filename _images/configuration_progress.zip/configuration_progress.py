#!/usr/bin/python                                                                                                                                                              

import sys
import requests
import configuration_conf

if len(sys.argv) < 2:
    print >> sys.stderr, "Error: Specify thread id as a parameter"
    sys.exit(1)

thread_id = sys.argv[1]

r = requests.get(configuration_conf.JIRA_REST + '/progress.json',
    auth=(configuration_conf.JIRA_USER, configuration_conf.JIRA_PASSWORD),
    params={'thread_id':thread_id})
sys.stdout.write(r.text)