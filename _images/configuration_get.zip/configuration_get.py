#!/usr/bin/python                                                                                                                                                              

import sys
import requests
import configuration_conf

r = requests.get(configuration_conf.JIRA_REST,
    auth=(configuration_conf.JIRA_USER, configuration_conf.JIRA_PASSWORD))
sys.stdout.write(r.text)
