#!/usr/bin/python                                                                                                                                                              

import sys
import requests
import configuration_conf

if len(sys.argv) < 2:
    print >> sys.stderr, "Error:Specify configuration file name as a first parameter"
    sys.exit(1)

file_name = sys.argv[1]
ids = len(sys.argv) > 2 and sys.argv[2].split(',') or []

files = {'file': open(file_name, 'rb')}
data = {'confirmed-delete[]': ids}

r = requests.post(configuration_conf.JIRA_REST + '.json',
    auth = (configuration_conf.JIRA_USER, configuration_conf.JIRA_PASSWORD),
    files = files,
    data = data)

sys.stdout.write(r.text)
